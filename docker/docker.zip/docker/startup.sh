#!/bin/bash
# 使用docker-compose对相应的类型进行操作

# docker-compose的命令: up,stop,down,logs
DOCKER_COMMAND=$1
# 类型: es,nacos,skywalking
CLUSTER_TYPE=$2

CLUSTER_NAME=""
case $DOCKER_COMMAND in
    up)  DOCKER_COMMAND="up -d"
    ;;
    stop) DOCKER_COMMAND="stop"
    ;;
    down) DOCKER_COMMAND="down"
    ;;
    logs) DOCKER_COMMAND="logs --tail=100 -t"
    ;;
    logsf) DOCKER_COMMAND="logs --tail=100 -t -f"
    ;;
    *)
    ;;
esac

case $CLUSTER_TYPE in
    es)  CLUSTER_NAME="es01 es02 es03 kibana"
    ;;
    nacos) CLUSTER_NAME="mysql nacos01 nacos02 nacos03 prometheus grafana"
    ;;
    skywalking) CLUSTER_NAME="skywalking-oap01 skywalking-oap02 skywalking-ui"
    ;;
    *)
    ;;
esac

COMMAND="docker-compose $DOCKER_COMMAND $CLUSTER_NAME"
echo "执行命令为：$COMMAND"
$COMMAND